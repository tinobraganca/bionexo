import { Component, OnInit } from '@angular/core';
import { HttpRestService } from "../service/httprest.service"


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
  providers: [HttpRestService]
})
export class SearchComponent implements OnInit {

  resposta:string = '';

  constructor(private httpRestService: HttpRestService) { }

  ngOnInit() {
    this.httpRestService.consultaLatLongApiGeo(this.resposta).subscribe();
  }

 
  public atualizaResposta(resposta: Event): void {
    this.resposta = (<HTMLInputElement> resposta.target).value;
    console.log(this.resposta);
    this.httpRestService.consultaLatLongApiGeo(this.resposta).subscribe(
      (resposta: any) => {
        console.log(resposta.lat);
        console.log(resposta.lng);
      }
    );
  }

}
